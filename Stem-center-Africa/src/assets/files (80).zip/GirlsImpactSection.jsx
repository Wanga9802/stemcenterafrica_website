import { useState, useEffect } from 'react';
import '../../Styles/GirlsImpactSection.css';

// Swap these for your real WoSTEM photos — keep the same variable names.
import avatar1 from '../../assets/wostem/testimonial-akinyi.jpg';
import avatar2 from '../../assets/wostem/testimonial-2.jpg';
import avatar3 from '../../assets/wostem/testimonial-3.jpg';

import momentImg1 from '../../assets/wostem/moment-1.jpg';
import momentImg2 from '../../assets/wostem/moment-2.jpg';
import momentImg3 from '../../assets/wostem/moment-3.jpg';

const TESTIMONIALS = [
  {
    id: 1,
    quote:
      'WO STEM gave me the confidence to believe in myself. I love building robots and I dream of becoming an engineer who will build solutions for my community.',
    name: 'Akinyi, 15',
    role: 'STEM Center Africa Learner',
    avatar: avatar1,
  },
  {
    id: 2,
    quote:
      'Before WO STEM, I never thought coding was for girls like me. Now I build my own websites and I want to study computer science after school.',
    name: 'Wanjiru, 14',
    role: 'STEM Center Africa Learner',
    avatar: avatar2,
  },
  {
    id: 3,
    quote:
      'I used to be shy about asking questions in class. Here, my mentors encourage me to try, fail, and try again. I feel like I can do anything now.',
    name: 'Naliaka, 16',
    role: 'STEM Center Africa Learner',
    avatar: avatar3,
  },
];

const MOMENTS = [momentImg1, momentImg2, momentImg3];

const AUTO_ROTATE_MS = 5000;

const GirlsImpactSection = () => {
  const [activeIndex, setActiveIndex] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setActiveIndex((prev) => (prev + 1) % TESTIMONIALS.length);
    }, AUTO_ROTATE_MS);
    return () => clearInterval(timer);
  }, []);

  const active = TESTIMONIALS[activeIndex];

  return (
    <section className="gis-section">
      <div className="container">
        <div className="row gis-row align-items-stretch">

          {/* ── Left: Testimonial carousel ── */}
          <div className="col-md-5">
            <span className="gis-eyebrow">Girls. Dreams. Impact.</span>
            <h2 className="gis-title">Real Stories, Real Impact</h2>

            <div className="gis-testimonial">
              <span className="gis-testimonial__quote-mark">&ldquo;</span>

              <div className="gis-testimonial__content" key={active.id}>
                <div className="gis-testimonial__avatar-wrap">
                  <img
                    src={active.avatar}
                    alt={active.name}
                    className="gis-testimonial__avatar"
                  />
                </div>

                <p className="gis-testimonial__text">{active.quote}</p>

                <p className="gis-testimonial__name">— {active.name}</p>
                <p className="gis-testimonial__role">{active.role}</p>
              </div>

              <div className="gis-dots">
                {TESTIMONIALS.map((t, i) => (
                  <button
                    key={t.id}
                    className={`gis-dot ${i === activeIndex ? 'gis-dot--active' : ''}`}
                    onClick={() => setActiveIndex(i)}
                    aria-label={`Show testimonial ${i + 1}`}
                  />
                ))}
              </div>
            </div>
          </div>

          {/* ── Right: Moments that matter ── */}
          <div className="col-md-7">
            <span className="gis-eyebrow">Moments That Matter</span>
            <h2 className="gis-title">Inspiring Girls Every Day</h2>

            <div className="gis-moments">
              {MOMENTS.map((img, i) => (
                <div className="gis-moments__item" key={i}>
                  <img src={img} alt={`WoSTEM moment ${i + 1}`} />
                </div>
              ))}
            </div>
          </div>

        </div>
      </div>
    </section>
  );
};

export default GirlsImpactSection;
